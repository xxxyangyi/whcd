package com.hand.dao;

import com.hand.dao.common.IOperation;
import com.hand.entity.User;

public interface IUserDao extends IOperation<User> {
}
